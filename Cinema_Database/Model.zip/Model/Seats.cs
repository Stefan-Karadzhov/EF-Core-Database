﻿
namespace Cinema_Database.Model
{
   public class Seats
    {
        public int Id { get; set; }

        public int HallId { get; set; }

        public Halls Hall { get; set; }
    }
}
